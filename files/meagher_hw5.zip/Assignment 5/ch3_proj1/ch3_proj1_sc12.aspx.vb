﻿
Partial Class ch3_proj1_sc12
    Inherits System.Web.UI.Page

End Class
