﻿
Partial Class ch3_proj1
    Inherits System.Web.UI.MasterPage
End Class

