﻿
Partial Class ch3_proj1
    Inherits System.Web.UI.Page

End Class
